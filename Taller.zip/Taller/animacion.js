var campos_max = 10; //max de 10 campos
$(document).ready(function () {
  var x = 0;
  $("#add-item").click(function () {
    //e.preventDefault();     //prevenir novos clicks
    //if (x < campos_max) {
    /*$('container').append('<div>\
                                <input type="text" name="campo[]">\
                                <a href="#" class="remover_campo">Remover</a>\
                                </div>');
                        x++;*/
    //}
    x++;
    let html = $("#contenedor").html();
    let new_control = $("#flecha").html();
    new_control = new_control
      .replace("cu0", "cu" + x)
      .replace("cubtn0", "cubtn" + x);
    $("#contenedor").html(new_control + html);

    $(".delete").click(function () {
      /*$(this).parent('#flecha').remove();
                        x--;*/
      let id = $(this).attr("id");
      let consecutivo = id.replace("cubtn", "");
      $("#cu" + consecutivo).remove();
    });
  });
  function contar() {
    $("#contador").val($("#descripcion").val().length + " Caracteres");
    $("#contador").addClass("mui--is-not-empty");
  }
});
function capturar() {
  let nombre = document.getElementById("nombre").value;
  let descripcion = document.getElementById("descripcion").value;
  let fecha = document.getElementById("fecha").value;
  document.getElementById("name").innerHTML = nombre + "";
  document.getElementById("descrip").innerHTML = descripcion + "";
  document.getElementById("name-info").innerHTML = nombre + "";
  document.getElementById("descrip-info").innerHTML = descripcion + "";
  document.getElementById("date").innerHTML = fecha + "";
}
function habilitar() {
  let nombre = document.getElementById("nombre").value;
  let descri = document.getElementById("descripcion").value;
  let fecha = document.getElementById("fecha").value;
  let val = 0;
  if (nombre == "") {
    val++;
  }
  if (descri == "") {
    val++;
  }
  if (val == 0) {
    document.getElementById("guardar").disabled = false;
  } else {
    document.getElementById("guardar").disabled = true;
  }
}
document.getElementById("nombre").addEventListener("keyup", habilitar);
document.getElementById("descripcion").addEventListener("keyup", habilitar);
