var campos_max          = 10;   //max de 10 campos
$(document).ready(function(){
        var x = 0;
        $('#add-item').click (function() {
                //e.preventDefault();     //prevenir novos clicks
                //if (x < campos_max) {
                        /*$('container').append('<div>\
                                <input type="text" name="campo[]">\
                                <a href="#" class="remover_campo">Remover</a>\
                                </div>');
                        x++;*/
                //}
                x++;
                let html =$("#contenedor").html();
                let new_control = $('#flecha').html();
                new_control = new_control.replace('cu0','cu'+x).replace('cubtn0','cubtn'+x);
                $("#contenedor").html(new_control+html);
               
                $('.delete').click(function() {
                        /*$(this).parent('#flecha').remove();
                        x--;*/
                let id = $(this).attr('id');
                let consecutivo = id.replace('cubtn','');
                        $('#cu'+consecutivo).remove();
                        
                })
        });
        
        $('.delete').click(function() {
                /*$(this).parent('#flecha').remove();
                x--;*/
                
        })
        

});